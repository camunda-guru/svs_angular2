import {Component} from '@angular/core';

@Component({
	selector: 'app-index',
	templateUrl: './app/index/index.component.html'
})
export class IndexComponent {
	constructor() {
		// TODO
	}
}
